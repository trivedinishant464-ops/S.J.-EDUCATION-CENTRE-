
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "school.db"));

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','teacher','parent','student')),
  name TEXT NOT NULL,
  class_name TEXT DEFAULT '',
  roll_no TEXT DEFAULT '',
  active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS homework (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_name TEXT NOT NULL,
  subject TEXT NOT NULL,
  title TEXT NOT NULL,
  details TEXT NOT NULL,
  due_date TEXT NOT NULL,
  created_by INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')),
  UNIQUE(student_id,date)
);
CREATE TABLE IF NOT EXISTS timetable (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_name TEXT NOT NULL,
  day TEXT NOT NULL,
  period TEXT NOT NULL,
  time TEXT NOT NULL,
  subject TEXT NOT NULL,
  teacher TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL UNIQUE,
  total REAL DEFAULT 0,
  paid REAL DEFAULT 0,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  exam TEXT NOT NULL,
  subject TEXT NOT NULL,
  marks REAL DEFAULT 0,
  max_marks REAL DEFAULT 100
);
`);

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_SJ_SESSION_SECRET",
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==='production', maxAge: 1000*60*60*8}
}));
app.use(express.static(path.join(__dirname,"public")));

function requireAuth(req,res,next){
  if(!req.session.user) return res.status(401).json({error:"Please login"});
  next();
}
function requireRole(...roles){
  return (req,res,next)=>{
    if(!req.session.user || !roles.includes(req.session.user.role))
      return res.status(403).json({error:"Not authorized"});
    next();
  };
}

app.get("/api/setup-status",(req,res)=>{
  const row = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role='admin'").get();
  res.json({adminExists: row.c > 0});
});

app.post("/api/setup", async (req,res)=>{
  const row = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role='admin'").get();
  if(row.c > 0) return res.status(400).json({error:"Admin setup is already completed."});
  const {username,password,name} = req.body;
  if(!username || !password || !name || password.length < 8)
    return res.status(400).json({error:"Name, admin ID and a password of at least 8 characters are required."});
  const hash = await bcrypt.hash(password,12);
  const info = db.prepare("INSERT INTO users(username,password_hash,role,name) VALUES(?,?,?,?)")
    .run(username.trim(),hash,"admin",name.trim());
  req.session.user = {id:info.lastInsertRowid,username:username.trim(),role:"admin",name:name.trim()};
  res.json({ok:true});
});

app.post("/api/login", async (req,res)=>{
  const {username,password} = req.body;
  const user = db.prepare("SELECT * FROM users WHERE username=? AND active=1").get(username);
  if(!user || !(await bcrypt.compare(password,user.password_hash)))
    return res.status(401).json({error:"Invalid ID or password"});
  req.session.user = {id:user.id,username:user.username,role:user.role,name:user.name,class_name:user.class_name,roll_no:user.roll_no};
  res.json({user:req.session.user});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",requireAuth,(req,res)=>res.json({user:req.session.user}));

app.get("/api/dashboard",requireAuth,(req,res)=>{
  const u=req.session.user;
  const notices=db.prepare("SELECT id,title,body,created_at FROM notices ORDER BY id DESC LIMIT 10").all();
  const homework = u.role==="admin" || u.role==="teacher"
    ? db.prepare("SELECT * FROM homework ORDER BY id DESC LIMIT 10").all()
    : db.prepare("SELECT * FROM homework WHERE class_name=? ORDER BY id DESC LIMIT 10").all(u.class_name||"");
  let data={notices,homework};
  if(u.role==="student" || u.role==="parent"){
    const sid = u.role==="student" ? u.id : null;
    if(sid){
      data.attendance=db.prepare("SELECT date,status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 30").all(sid);
      data.fees=db.prepare("SELECT * FROM fees WHERE student_id=?").get(sid) || {total:0,paid:0};
      data.results=db.prepare("SELECT * FROM results WHERE student_id=? ORDER BY id DESC").all(sid);
    }
  }
  if(u.role==="admin"){
    data.counts={
      users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
      students:db.prepare("SELECT COUNT(*) c FROM users WHERE role='student'").get().c,
      teachers:db.prepare("SELECT COUNT(*) c FROM users WHERE role='teacher'").get().c,
      parents:db.prepare("SELECT COUNT(*) c FROM users WHERE role='parent'").get().c
    };
  }
  res.json(data);
});

app.get("/api/users",requireRole("admin"),(req,res)=>{
  res.json(db.prepare("SELECT id,username,role,name,class_name,roll_no,active,created_at FROM users ORDER BY id DESC").all());
});

app.post("/api/users",requireRole("admin"),async(req,res)=>{
  const {username,password,role,name,class_name="",roll_no=""}=req.body;
  if(!username||!password||!role||!name) return res.status(400).json({error:"Required fields missing"});
  if(password.length<8) return res.status(400).json({error:"Password must be at least 8 characters"});
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(username,password_hash,role,name,class_name,roll_no) VALUES(?,?,?,?,?,?)")
      .run(username.trim(),hash,role,name.trim(),class_name,roll_no);
    res.json({ok:true,id:info.lastInsertRowid});
  }catch(e){res.status(400).json({error:"User ID already exists"});}
});

app.post("/api/users/:id/reset-password",requireRole("admin"),async(req,res)=>{
  const {password}=req.body;
  if(!password || password.length<8) return res.status(400).json({error:"Password must be at least 8 characters"});
  const hash=await bcrypt.hash(password,12);
  db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash,req.params.id);
  res.json({ok:true});
});
app.post("/api/users/:id/toggle",requireRole("admin"),(req,res)=>{
  db.prepare("UPDATE users SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.post("/api/notices",requireRole("admin","teacher"),(req,res)=>{
  const {title,body}=req.body;
  if(!title||!body) return res.status(400).json({error:"Title and message are required"});
  db.prepare("INSERT INTO notices(title,body,created_by) VALUES(?,?,?)").run(title,body,req.session.user.id);
  res.json({ok:true});
});

app.post("/api/homework",requireRole("admin","teacher"),(req,res)=>{
  const {class_name,subject,title,details,due_date}=req.body;
  if(!class_name||!subject||!title||!details||!due_date) return res.status(400).json({error:"All homework fields are required"});
  db.prepare("INSERT INTO homework(class_name,subject,title,details,due_date,created_by) VALUES(?,?,?,?,?,?)")
    .run(class_name,subject,title,details,due_date,req.session.user.id);
  res.json({ok:true});
});

app.post("/api/attendance",requireRole("admin","teacher"),(req,res)=>{
  const {student_id,date,status}=req.body;
  if(!student_id||!date||!["Present","Absent","Late"].includes(status)) return res.status(400).json({error:"Invalid attendance"});
  db.prepare(`INSERT INTO attendance(student_id,date,status) VALUES(?,?,?)
    ON CONFLICT(student_id,date) DO UPDATE SET status=excluded.status`).run(student_id,date,status);
  res.json({ok:true});
});

app.get("/api/students",requireRole("admin","teacher"),(req,res)=>{
  res.json(db.prepare("SELECT id,username,name,class_name,roll_no FROM users WHERE role='student' AND active=1 ORDER BY name").all());
});

app.get("/api/timetable",requireAuth,(req,res)=>{
  const c=req.session.user.class_name || req.query.class_name || "";
  res.json(db.prepare("SELECT * FROM timetable WHERE class_name=? ORDER BY id").all(c));
});

app.post("/api/timetable",requireRole("admin"),(req,res)=>{
  const {class_name,day,period,time,subject,teacher}=req.body;
  db.prepare("INSERT INTO timetable(class_name,day,period,time,subject,teacher) VALUES(?,?,?,?,?,?)")
    .run(class_name,day,period,time,subject,teacher);
  res.json({ok:true});
});

app.post("/api/fees",requireRole("admin"),(req,res)=>{
  const {student_id,total,paid}=req.body;
  db.prepare(`INSERT INTO fees(student_id,total,paid) VALUES(?,?,?)
    ON CONFLICT(student_id) DO UPDATE SET total=excluded.total,paid=excluded.paid,updated_at=CURRENT_TIMESTAMP`)
    .run(student_id,total||0,paid||0);
  res.json({ok:true});
});

app.post("/api/results",requireRole("admin","teacher"),(req,res)=>{
  const {student_id,exam,subject,marks,max_marks=100}=req.body;
  db.prepare("INSERT INTO results(student_id,exam,subject,marks,max_marks) VALUES(?,?,?,?,?)")
    .run(student_id,exam,subject,marks,max_marks);
  res.json({ok:true});
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`S.J EDUCATION CENTRE app running at http://localhost:${PORT}`));
